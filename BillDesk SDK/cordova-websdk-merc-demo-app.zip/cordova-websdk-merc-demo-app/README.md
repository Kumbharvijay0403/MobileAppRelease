# cordova-websdk-merc-demo-app
This demo app showcasing cordova and web-sdk integration
