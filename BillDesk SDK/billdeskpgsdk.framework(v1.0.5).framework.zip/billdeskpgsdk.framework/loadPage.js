function loadpage(merchantLogo,flowType,flow_config, theme) {
    
    var config = JSON.parse(flow_config)
    
    if(flowType == "Pay + Mandate"){
        flowType = "payments"
        config["prefs"] = {}
        config["prefs"]["mandate"] = {}
        config["prefs"]["payment_categories"] = config.paymentCategories
        config["prefs"]["mandate"]["mandate_required"] = config.isMandateRequired
        config["prefs"]["mandate"]["personal_details"] = config.personalDetails

        delete config.paymentCategories
        delete config.isMandateRequired
        delete config.personalDetails
    }

    var responseHandler = function (response) {
      window.location.href = "billdesksdk://web-flow?status="+response.status+"&response="+response.txnResponse
    }

    const sdkConfig = {
      merchantLogo: merchantLogo,
      flowConfig: config,
      responseHandler: responseHandler,
      flowType: flowType,
      themeConfig : JSON.parse(theme)
    }

    window.loadBillDeskSdk(sdkConfig);
}
