//
//  billdeskpgsdk.h
//  billdeskpgsdk
//
//  Created by Bharat on 17/05/21.
//

#import <Foundation/Foundation.h>

//! Project version number for billdeskpgsdk.
FOUNDATION_EXPORT double billdeskpgsdkVersionNumber;

//! Project version string for billdeskpgsdk.
FOUNDATION_EXPORT const unsigned char billdeskpgsdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <billdeskpgsdk/PublicHeader.h>


